exports.Prefix = `!`;
exports.Token = `your bot token`;
exports.Color = `RANDOM`;
